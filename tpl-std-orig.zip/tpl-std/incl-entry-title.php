<table class='entry'>
<tr><td>Category:</td><td><?php echo $cat ?></td></tr>
<tr><td>Title:</td><td><?php echo $t1 ?></td></tr>
<tr><td>Subtitle:</td><td><?php echo $t2 ?></td></tr>
</table>
