<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="robots" content="noarchive,nofollow" />
<meta http-equiv="cache-control" content="no-cache" />
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" />
<title></title>
<link href='tpl-std/tpl.css' rel='stylesheet' type='text/css' media='screen' />
<link rel="shortcut icon" href="img/favicon.ico" />

<script type="text/javascript" src="sv.js"></script>  
